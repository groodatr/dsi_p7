import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VerContactoPage } from './ver-contacto';

@NgModule({
  declarations: [
    VerContactoPage,
  ],
  imports: [
    IonicPageModule.forChild(VerContactoPage),
  ],
})
export class VerContactoPageModule {}
